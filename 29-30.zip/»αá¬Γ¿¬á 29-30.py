import turtle #подключение библиотеки черепаха
turtle.bgcolor("#a5cff2")
turtle.shape("turtle")
turtle.forward(300)#вперед
turtle.right(90)#направо
turtle.forward(300)
turtle.right(90)
turtle.forward(300)
turtle.right(90)
turtle.forward(300)


turtle.mainloop()#не закрывает окно


'''
Сокращенные записи программного кода
'''
#import random #подключаем всю библиотеку random (все 902 строки)
#из библиотеки random подключаем только ф-цию randint
#остальные ф-ции не подключены
from random import randint
#полная запись
list1 =[]
for i in range(0,10): #проходим по всему списку
    list1.append(randint(-10,10))
    print(list1[i],end=" ")#печать по 1ому элементу
print(f"\n{list1}")#печать всего списка
#сокращенная запись
list1 = [randint(-10,10) for _ in range(10)]
print(f"\nlist1: {list1}")#печать всего списка
list2 = [randint(-10,10) for _ in range(10)]
print(f"\nlist2: {list2}")#печать всего списка
#объединяем оба списка
list3 = list1+list2
print(f"\nlist3: {list3}")
#убираем дубликаты и соединяем оба списка в один
#Тип данных - то, какие данные храним в переменной(списке,множеcтве и т.д)
#list - список, используем как тип_данных
#set - множество, хранит только уникальные значения
num = 10 #целое число
num1 = 0.5 #дробное число
str1 = "hello" #строки
list4 = list(set(list3))
print(list4)
#список, который содержит только уникальные элементы из обоих списков
#Добавляем элемент из list1, если он не присуствует в списке list2
#Добавляем элемент из list2, если он не присуствует в списке list1
list5 = list(set([i for i in list1 if i not in list2]+
                 [i for i in list2 if i not in list1]))
print(f"list5: {list5}")
